package br.ufc.npi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoestudoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutoestudoApplication.class, args);
	}
}
