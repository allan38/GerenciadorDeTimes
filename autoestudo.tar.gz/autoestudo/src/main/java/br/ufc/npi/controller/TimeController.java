package br.ufc.npi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(path = "/time/")
public class TimeController {
	
	@RequestMapping(path="/")
	public String index(){
		return "time";
	}

}
